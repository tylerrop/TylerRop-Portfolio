<?php 
	require_once 'config.php';

	$title = 'Password Reset' . TITLEADDONE; 

	$content = '
	<div class="container roundCorners">
		<div class="jumbotron roundCorners">
			<h1>Title</h1> 
	    	<h2>Sub Title</h2> 
	    	<p>Some static text</p>
	    </div>
	</div>
	'; 

	require_once('master.php');

?>