<?php
	define('DBHOST', 'localhost');
	define('DBNAME', 'curriculum');
	define('DBUSER', 'root');
	define('DBPASS', '');
	define('TITLEADDON', ' | MRU Curriculum');
	define("MAJOR_CHANGE_STACK", serialize (array("FCC", "AB")));
	define("APPROVAL_NOTIFIER_EMAIL", "trop315@mtroyal.ca");
?>