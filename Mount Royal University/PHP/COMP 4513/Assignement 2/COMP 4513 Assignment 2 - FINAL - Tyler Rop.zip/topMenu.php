<div class="container roundCorners">
<div class="navbar navbar-default roundCorners col-md-12 col-lg-12 topMenuShrunkPadding" >
        <div class="container-fluid">
          <!-- <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Project name</a> -->
          </div>

          <!-- <div class="navbar-collapse"> -->
          <div class="navbar-collapse">
            <ul class="nav navbar-nav bold">
              <!-- <li><a href="createCourse.php">Create Course</a></li>
              <li><a href="viewCourses.php">View Courses</a></li> -->

              <li><a href="createProgram.php">Create Program Request</a></li>
              <li><a href="viewPrograms.php">All Program Requests</a></li>
              <li><a href="yourPrograms.php">Your Requests</a></li>
              <li><a href="yourPendingProgramApprovals.php">Pending Your Approval</a></li>
              <li><a href="approvedPrograms.php">Approved Programs</a></li>
              <li><a href="unapprovedPrograms.php">Unapproved Programs</a></li>
            </ul>
            <!-- <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="./">Default</a></li>
              <li><a href="../navbar-static-top/">Static top</a></li>
              <li><a href="../navbar-fixed-top/">Fixed top</a></li>
            </ul> -->
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
</div>
</div>

